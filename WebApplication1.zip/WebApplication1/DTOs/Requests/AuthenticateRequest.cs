﻿namespace WebApplication1.DTOs.Requests
{
    public class AuthenticateRequest
    {
        public string user_name { get; set; }
        public string password { get; set; }

        

    }

}
